#ifndef SELECTVAR_H
#define SELECTVAR_H

#include "basic.h"

void updateCountNum(CNF * cnf);
void updateCountNum_2(CNF * cnf);
int FindMax_2(CNF * cnf);
int FindMax(CNF *cnf);
int Findmax_new_2(CNF * cnf);
int ReverseOrder(CNF * cnf);
int InOrder(CNF * cnf);
int SelectVar(CNF * cnf);
int LeastLength(CNF * cnf);
#endif // !SELECTVAR_H
