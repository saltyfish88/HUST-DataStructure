#ifndef __LEXER_DEF__
#define __LEXER_DEF__
#include<stdio.h>
#include<stdlib.h>
#include<ctype.h>
#include<string.h>
#define MAXLEN_OF_CONTENT 50
#define MAXLEN 1000
#include"lexer_datastructure.h"
#include"lexer_head.h"
#include"lexer_func.c"
#endif
