#ifndef __PARSER_DEF__
#define __PARSER_DEF__
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<stdarg.h>
#define LOST 1
#define WRONG 0
#define MAXLEN_OF_CONTENT 50
#define MAXLEN 1000

#include"parser_datastructure.h"
#include"parser_head.h"
#include"parser_func.c"
#endif
